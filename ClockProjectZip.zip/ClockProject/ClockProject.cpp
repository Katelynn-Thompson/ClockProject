/*Katelynn Thompson
Eric Greggori - CS-210
01/22/23
*/

#include <iostream>
#include <ctime>
//Had trouble with the variable localtime added pragma
#pragma warning(disable : 4996)

using namespace std;

time_t now = time(0);
tm* local = localtime(&now);

int hour = local->tm_hour;
int minutes = local->tm_min;
int sec = local->tm_sec;

// Function to display the 12-hour clock
void Clock12() {
    int t = hour;
    // Converts 24-hour clock to 12-hour
    if (hour > 12) {
        t -= 12;
    }
    cout << "*****************************" << "     " << "*****************************\n";
    cout << "*       12-Hour Clock       *" << "     " << "*       24-Hour Clock       *\n";
    cout << "*         " << (t < 10 ? "0" : "") << t << ":" << (minutes < 10 ? "0" : "") << minutes << ":" << (sec < 10 ? "0" : "") << sec << (hour < 12 ? " AM" : " PM") << "       *     ";
}

// Function to display the 24-hour clock
void Clock24() {
    //if (hour >10) hour += 12;
    cout << "*         " << (hour < 10 ? "0" : "") << hour << ":" << (minutes < 10 ? "0" : "") << minutes << ":" << (sec < 10 ? "0" : "") << sec << "          *       \n";
    cout << "*****************************" << "     " << "*****************************\n";
}

// Function to add one hour to the clock w/timecap
void AddOneHour() {
    hour++;
    if (hour > 23) {
        hour = 0;
    }
}

// Function to add one minute to the clock w/timecap
void AddOneMinute() {
    minutes++;
    if (minutes > 59) {
        minutes = 0;
        hour++;
    }
    if (hour > 23) {
        hour = 0;
    }
}

// Function to add one second to the clock w/timecap
void AddOneSecond() {
    sec++;
    if (sec > 59) {
        sec = 0;
        minutes++;
    }
    if (minutes > 59) {
        minutes = 0;
        hour++;
    }
    if (hour > 23) {
        hour = 0;
    }
}

int main() {
    int choice;

    while (true) {

        Clock12();
        Clock24();

        cout << "\n1 - Add One Hour" << endl;
        cout << "2 - Add One Minute" << endl;
        cout << "3 - Add One Second" << endl;
        cout << "4 - Exit Program" << endl;

        cin >> choice;
        switch (choice) {
        case 1:
            AddOneHour();
            break;
        case 2:
            AddOneMinute();
            break;
        case 3:
            AddOneSecond();
            break;
        case 4:
            return 0;
        }
    }
}